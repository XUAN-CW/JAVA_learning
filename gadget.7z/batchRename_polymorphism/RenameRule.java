package batchRename_polymorphism;

public interface RenameRule {
    String getNewName(String oldName);
}
