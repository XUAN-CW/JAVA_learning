module gadget {
	exports txtInputSimulator;
	exports txtInputSimulator06;
	exports txtInputSimulator05;
	exports txtInputSimulator04;
	exports txtInputSimulator03;
	exports txtInputSimulator02;
	exports txtInputSimulator01;
	exports jScrollPaneDemo;

	requires java.desktop;
	requires java.sql;
	requires jdk.sctp;
}