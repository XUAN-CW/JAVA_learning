package txtInputSimulator05;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import txtInputSimulator05_2.MyFrame;

/***
 * �� robot �����˳���
 */

public class Main {
	public static void main(String[] args)
	{
		/** �������� */
		MyFrame myFrame =new MyFrame();
		myFrame.setVisible(true);
	}
}
