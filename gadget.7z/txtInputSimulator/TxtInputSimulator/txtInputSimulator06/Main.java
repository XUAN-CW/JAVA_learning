package txtInputSimulator06;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JOptionPane;

import txtInputSimulator06.MyFrame;

/***
 * �� robot �����˳���
 */

public class Main {
	public static void main(String[] args)
	{
		/** �������� */
		MyFrame myFrame =new MyFrame();
		myFrame.setVisible(true);
	}
}
